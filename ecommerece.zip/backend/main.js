const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Simple in-memory database (replace with real DB in production)
let users = [];
let products = [
  { id: 1, name: 'Laptop', price: 999, description: 'High-performance laptop', image: '💻' },
  { id: 2, name: 'Phone', price: 699, description: 'Latest smartphone', image: '📱' },
  { id: 3, name: 'Headphones', price: 199, description: 'Noise-cancelling headphones', image: '🎧' },
  { id: 4, name: 'Watch', price: 299, description: 'Smart watch', image: '⌚' }
];
let orders = [];
let carts = {};

const JWT_SECRET = 'your-secret-key';

// Auth middleware
const authenticate = (req, res, next) => {
  const token = req.header('Authorization');
  if (!token) return res.status(401).json({ error: 'No token' });

  try {
    const decoded = jwt.verify(token.replace('Bearer ', ''), JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// User registration
app.post('/register', async (req, res) => {
  const { email, password, name } = req.body;
  
  if (users.find(u => u.email === email)) {
    return res.status(400).json({ error: 'User already exists' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const user = { id: users.length + 1, email, password: hashedPassword, name };
  users.push(user);

  const token = jwt.sign({ id: user.id, email }, JWT_SECRET);
  res.json({ token, user: { id: user.id, email, name } });
});

// User login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);

  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(400).json({ error: 'Invalid credentials' });
  }

  const token = jwt.sign({ id: user.id, email }, JWT_SECRET);
  res.json({ token, user: { id: user.id, email, name: user.name } });
});

// Get all products
app.get('/products', (req, res) => {
  res.json(products);
});

// Get product by ID
app.get('/products/:id', (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(product);
});

// Add to cart
app.post('/cart', authenticate, (req, res) => {
  const { productId, quantity } = req.body;
  const userId = req.user.id;

  if (!carts[userId]) carts[userId] = [];
  
  const existingItem = carts[userId].find(item => item.productId === productId);
  if (existingItem) {
    existingItem.quantity += quantity;
  } else {
    carts[userId].push({ productId, quantity });
  }

  res.json(carts[userId]);
});

// Get cart
app.get('/cart', authenticate, (req, res) => {
  const userId = req.user.id;
  res.json(carts[userId] || []);
});

// Create order
app.post('/orders', authenticate, (req, res) => {
  const userId = req.user.id;
  const cart = carts[userId] || [];
  
  if (cart.length === 0) {
    return res.status(400).json({ error: 'Cart is empty' });
  }

  const order = {
    id: orders.length + 1,
    userId,
    items: [...cart],
    total: cart.reduce((sum, item) => {
      const product = products.find(p => p.id === item.productId);
      return sum + (product.price * item.quantity);
    }, 0),
    date: new Date().toISOString()
  };

  orders.push(order);
  carts[userId] = []; // Clear cart

  res.json(order);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});