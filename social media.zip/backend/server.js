const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./database');
const app = express();
const PORT = 3001
;

app.use(cors());
app.use(express.json());

const JWT_SECRET = 'social-media-secret-key';

// Auth middleware
const authenticate = async (req, res, next) => {
    const token = req.header('Authorization');
    if (!token) return res.status(401).json({ error: 'No token' });

    try {
        const decoded = jwt.verify(token.replace('Bearer ', ''), JWT_SECRET);
        
        // Verify user still exists in database
        const result = await db.query('SELECT id, email FROM users WHERE id = $1', [decoded.id]);
        if (result.rows.length === 0) {
            return res.status(401).json({ error: 'User not found' });
        }
        
        req.user = decoded;
        next();
    } catch (err) {
        res.status(401).json({ error: 'Invalid token' });
    }
};

// User registration
app.post('/register', async (req, res) => {
    const { username, email, password, name } = req.body;
    
    try {
        // Check if user exists
        const userCheck = await db.query(
            'SELECT id FROM users WHERE email = $1 OR username = $2',
            [email, username]
        );

        if (userCheck.rows.length > 0) {
            return res.status(400).json({ error: 'Email or username already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const result = await db.query(
            'INSERT INTO users (username, email, password, name) VALUES ($1, $2, $3, $4) RETURNING id, username, email, name, bio, avatar',
            [username, email, hashedPassword, name]
        );

        const user = result.rows[0];
        const token = jwt.sign({ id: user.id, email }, JWT_SECRET);
        
        res.json({ 
            token, 
            user 
        });
    } catch (err) {
        console.error('Registration error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// User login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const result = await db.query(
            'SELECT * FROM users WHERE email = $1',
            [email]
        );

        const user = result.rows[0];
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign({ id: user.id, email }, JWT_SECRET);
        
        // Remove password from response
        const { password: _, ...userWithoutPassword } = user;
        
        res.json({ 
            token, 
            user: userWithoutPassword 
        });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get user profile
app.get('/users/:id', async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        
        const userResult = await db.query(
            `SELECT id, username, email, name, bio, avatar, created_at 
             FROM users WHERE id = $1`,
            [userId]
        );

        if (userResult.rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        const user = userResult.rows[0];

        // Get follower counts
        const followersCount = await db.query(
            'SELECT COUNT(*) FROM followers WHERE following_id = $1',
            [userId]
        );

        const followingCount = await db.query(
            'SELECT COUNT(*) FROM followers WHERE follower_id = $1',
            [userId]
        );

        // Get post count
        const postCount = await db.query(
            'SELECT COUNT(*) FROM posts WHERE user_id = $1',
            [userId]
        );

        user.followersCount = parseInt(followersCount.rows[0].count);
        user.followingCount = parseInt(followingCount.rows[0].count);
        user.postsCount = parseInt(postCount.rows[0].count);

        res.json(user);
    } catch (err) {
        console.error('Get user error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Update user profile
app.put('/profile', authenticate, async (req, res) => {
    const { name, bio, avatar } = req.body;
    
    try {
        const result = await db.query(
            `UPDATE users 
             SET name = $1, bio = $2, avatar = $3, updated_at = CURRENT_TIMESTAMP 
             WHERE id = $4 
             RETURNING id, username, email, name, bio, avatar`,
            [name, bio, avatar, req.user.id]
        );

        res.json(result.rows[0]);
    } catch (err) {
        console.error('Update profile error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Create post
app.post('/posts', authenticate, async (req, res) => {
    const { content } = req.body;
    
    try {
        const result = await db.query(
            `INSERT INTO posts (user_id, content) 
             VALUES ($1, $2) 
             RETURNING *`,
            [req.user.id, content]
        );

        const post = result.rows[0];
        
        // Get user details for the post
        const userResult = await db.query(
            'SELECT id, username, name, avatar FROM users WHERE id = $1',
            [req.user.id]
        );

        post.user = userResult.rows[0];
        post.likes = [];
        post.comments = [];
        post.isLiked = false;

        res.json(post);
    } catch (err) {
        console.error('Create post error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get all posts (feed)
app.get('/posts', authenticate, async (req, res) => {
    try {
        const result = await db.query(
            `SELECT p.*, 
                    u.username, u.name, u.avatar,
                    COUNT(DISTINCT l.id) as like_count,
                    COUNT(DISTINCT c.id) as comment_count,
                    EXISTS(SELECT 1 FROM likes WHERE post_id = p.id AND user_id = $1) as is_liked
             FROM posts p
             JOIN users u ON p.user_id = u.id
             LEFT JOIN likes l ON p.id = l.post_id
             LEFT JOIN comments c ON p.id = c.post_id
             GROUP BY p.id, u.id
             ORDER BY p.created_at DESC`,
            [req.user.id]
        );

        const posts = result.rows.map(row => ({
            id: row.id,
            userId: row.user_id,
            content: row.content,
            timestamp: row.created_at,
            user: {
                id: row.user_id,
                username: row.username,
                name: row.name,
                avatar: row.avatar
            },
            likes: Array(parseInt(row.like_count)).fill(0), // Simulate like count
            likeCount: parseInt(row.like_count),
            commentCount: parseInt(row.comment_count),
            isLiked: row.is_liked
        }));

        // Get comments for each post
        for (let post of posts) {
            const commentsResult = await db.query(
                `SELECT c.*, u.username, u.name, u.avatar 
                 FROM comments c 
                 JOIN users u ON c.user_id = u.id 
                 WHERE c.post_id = $1 
                 ORDER BY c.created_at ASC`,
                [post.id]
            );
            
            post.comments = commentsResult.rows.map(comment => ({
                id: comment.id,
                content: comment.content,
                timestamp: comment.created_at,
                user: {
                    id: comment.user_id,
                    username: comment.username,
                    name: comment.name,
                    avatar: comment.avatar
                }
            }));
        }

        res.json(posts);
    } catch (err) {
        console.error('Get posts error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Like/unlike post
app.post('/posts/:id/like', authenticate, async (req, res) => {
    const postId = parseInt(req.params.id);
    
    try {
        // Check if already liked
        const likeCheck = await db.query(
            'SELECT id FROM likes WHERE post_id = $1 AND user_id = $2',
            [postId, req.user.id]
        );

        if (likeCheck.rows.length > 0) {
            // Unlike
            await db.query(
                'DELETE FROM likes WHERE post_id = $1 AND user_id = $2',
                [postId, req.user.id]
            );
        } else {
            // Like
            await db.query(
                'INSERT INTO likes (post_id, user_id) VALUES ($1, $2)',
                [postId, req.user.id]
            );
        }

        // Get updated like count
        const likeCountResult = await db.query(
            'SELECT COUNT(*) FROM likes WHERE post_id = $1',
            [postId]
        );

        const isLikedResult = await db.query(
            'SELECT 1 FROM likes WHERE post_id = $1 AND user_id = $2',
            [postId, req.user.id]
        );

        res.json({ 
            likes: parseInt(likeCountResult.rows[0].count), 
            isLiked: isLikedResult.rows.length > 0 
        });
    } catch (err) {
        console.error('Like post error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Add comment
app.post('/posts/:id/comments', authenticate, async (req, res) => {
    const { content } = req.body;
    const postId = parseInt(req.params.id);
    
    try {
        const result = await db.query(
            `INSERT INTO comments (post_id, user_id, content) 
             VALUES ($1, $2, $3) 
             RETURNING *`,
            [postId, req.user.id, content]
        );

        const comment = result.rows[0];
        
        // Get user details
        const userResult = await db.query(
            'SELECT id, username, name, avatar FROM users WHERE id = $1',
            [req.user.id]
        );

        comment.user = userResult.rows[0];
        
        res.json(comment);
    } catch (err) {
        console.error('Add comment error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Follow/unfollow user
app.post('/users/:id/follow', authenticate, async (req, res) => {
    const targetUserId = parseInt(req.params.id);
    const currentUserId = req.user.id;
    
    if (targetUserId === currentUserId) {
        return res.status(400).json({ error: 'Cannot follow yourself' });
    }
    
    try {
        // Check if already following
        const followCheck = await db.query(
            'SELECT id FROM followers WHERE follower_id = $1 AND following_id = $2',
            [currentUserId, targetUserId]
        );

        if (followCheck.rows.length > 0) {
            // Unfollow
            await db.query(
                'DELETE FROM followers WHERE follower_id = $1 AND following_id = $2',
                [currentUserId, targetUserId]
            );
        } else {
            // Follow
            await db.query(
                'INSERT INTO followers (follower_id, following_id) VALUES ($1, $2)',
                [currentUserId, targetUserId]
            );
        }

        // Get updated follower count
        const followerCountResult = await db.query(
            'SELECT COUNT(*) FROM followers WHERE following_id = $1',
            [targetUserId]
        );

        const isFollowingResult = await db.query(
            'SELECT 1 FROM followers WHERE follower_id = $1 AND following_id = $2',
            [currentUserId, targetUserId]
        );

        res.json({ 
            isFollowing: isFollowingResult.rows.length > 0, 
            followersCount: parseInt(followerCountResult.rows[0].count) 
        });
    } catch (err) {
        console.error('Follow user error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Check if following
app.get('/users/:id/follow-status', authenticate, async (req, res) => {
    const targetUserId = parseInt(req.params.id);
    const currentUserId = req.user.id;
    
    try {
        const result = await db.query(
            'SELECT 1 FROM followers WHERE follower_id = $1 AND following_id = $2',
            [currentUserId, targetUserId]
        );

        res.json({ isFollowing: result.rows.length > 0 });
    } catch (err) {
        console.error('Check follow status error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get all users
app.get('/users', authenticate, async (req, res) => {
    try {
        const result = await db.query(
            `SELECT u.id, u.username, u.name, u.bio, u.avatar, u.created_at,
                    COUNT(f1.id) as followers_count,
                    COUNT(f2.id) as following_count,
                    EXISTS(SELECT 1 FROM followers WHERE follower_id = $1 AND following_id = u.id) as is_following
             FROM users u
             LEFT JOIN followers f1 ON u.id = f1.following_id
             LEFT JOIN followers f2 ON u.id = f2.follower_id
             WHERE u.id != $1
             GROUP BY u.id
             ORDER BY u.created_at DESC`,
            [req.user.id]
        );

        const users = result.rows.map(row => ({
            id: row.id,
            username: row.username,
            name: row.name,
            bio: row.bio,
            avatar: row.avatar,
            followersCount: parseInt(row.followers_count),
            followingCount: parseInt(row.following_count),
            isFollowing: row.is_following,
            createdAt: row.created_at
        }));

        res.json(users);
    } catch (err) {
        console.error('Get users error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.listen(PORT, () => {
    console.log(`Social Media API running on http://localhost:${PORT}`);
});