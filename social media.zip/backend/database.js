const { Pool } = require('pg');

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'social_media',
    password: 'password123', // Use the password you set
    port: 5432,
});

// Test connection
pool.connect((err, client, release) => {
    if (err) {
        console.error('Error connecting to PostgreSQL:', err);
        console.log('Please make sure:');
        console.log('1. PostgreSQL is running');
        console.log('2. Database "social_media" exists');
        console.log('3. Password is correct');
    } else {
        console.log('✅ Connected to PostgreSQL database successfully!');
        release();
    }
});

module.exports = {
    query: (text, params) => pool.query(text, params),
    pool
};