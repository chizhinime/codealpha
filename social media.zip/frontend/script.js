const API_BASE = 'http://localhost:3001';
let currentUser = null;
let token = localStorage.getItem('token');

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    if (token) {
        checkAuth();
    } else {
        showAuth();
    }
    
    // Navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tab = this.getAttribute('data-tab');
            showTab(tab);
        });
    });
    
    // Logout
    document.getElementById('logoutBtn').addEventListener('click', logout);
});

async function checkAuth() {
    try {
        // In a real app, you'd verify the token with the backend
        const userData = localStorage.getItem('user');
        if (userData) {
            currentUser = JSON.parse(userData);
            hideAuth();
            loadFeed();
        } else {
            showAuth();
        }
    } catch (err) {
        showAuth();
    }
}

async function register() {
    const name = document.getElementById('registerName').value;
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    if (!name || !username || !email || !password) {
        alert('Please fill all fields');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, username, email, password })
        });
        
        const data = await response.json();
        if (response.ok) {
            handleAuthSuccess(data);
        } else {
            alert(data.error);
        }
    } catch (err) {
        alert('Error: ' + err.message);
    }
}

async function login() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    if (!email || !password) {
        alert('Please fill all fields');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        if (response.ok) {
            handleAuthSuccess(data);
        } else {
            alert(data.error);
        }
    } catch (err) {
        alert('Error: ' + err.message);
    }
}

function handleAuthSuccess(data) {
    token = data.token;
    currentUser = data.user;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(currentUser));
    hideAuth();
    loadFeed();
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    token = null;
    currentUser = null;
    showAuth();
}

function showAuth() {
    document.getElementById('authSection').classList.remove('hidden');
    document.getElementById('appContent').classList.add('hidden');
}

function hideAuth() {
    document.getElementById('authSection').classList.add('hidden');
    document.getElementById('appContent').classList.remove('hidden');
    loadProfile();
}

function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab and activate nav button
    document.getElementById(tabName + 'Tab').classList.add('active');
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // Load tab content
    if (tabName === 'feed') loadFeed();
    if (tabName === 'profile') loadProfile();
    if (tabName === 'users') loadUsers();
}

async function loadFeed() {
    try {
        const response = await fetch(`${API_BASE}/posts`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const posts = await response.json();
        
        const container = document.getElementById('postsContainer');
        container.innerHTML = posts.map(post => `
            <div class="post" data-post-id="${post.id}">
                <div class="post-header">
                    <div class="post-avatar">${post.user.avatar}</div>
                    <div class="post-user-info">
                        <h3>${post.user.name}</h3>
                        <div class="post-timestamp">${new Date(post.timestamp).toLocaleString()}</div>
                    </div>
                </div>
                <div class="post-content">${post.content}</div>
                <div class="post-actions">
                    <button class="like-btn ${post.isLiked ? 'liked' : ''}" onclick="likePost(${post.id})">
                        ❤️ ${post.likes.length}
                    </button>
                    <button class="comment-btn" onclick="toggleComments(${post.id})">
                        💬 ${post.comments.length}
                    </button>
                </div>
                <div class="comments-section" id="comments-${post.id}" style="display: none;">
                    ${post.comments.map(comment => `
                        <div class="comment">
                            <div class="comment-avatar">${comment.user.avatar}</div>
                            <div class="comment-content">
                                <div class="comment-header">
                                    <strong>${comment.user.name}</strong>
                                    <span class="comment-timestamp">${new Date(comment.timestamp).toLocaleString()}</span>
                                </div>
                                <div>${comment.content}</div>
                            </div>
                        </div>
                    `).join('')}
                    <div class="add-comment">
                        <input type="text" id="comment-${post.id}" placeholder="Write a comment...">
                        <button onclick="addComment(${post.id})">Comment</button>
                    </div>
                </div>
            </div>
        `).join('');
    } catch (err) {
        alert('Error loading feed');
    }
}

async function createPost() {
    const content = document.getElementById('postContent').value;
    if (!content.trim()) return;

    try {
        const response = await fetch(`${API_BASE}/posts`, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ content })
        });
        
        if (response.ok) {
            document.getElementById('postContent').value = '';
            loadFeed();
        }
    } catch (err) {
        alert('Error creating post');
    }
}

async function likePost(postId) {
    try {
        const response = await fetch(`${API_BASE}/posts/${postId}/like`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (response.ok) {
            loadFeed();
        }
    } catch (err) {
        alert('Error liking post');
    }
}

function toggleComments(postId) {
    const commentsSection = document.getElementById(`comments-${postId}`);
    commentsSection.style.display = commentsSection.style.display === 'none' ? 'block' : 'none';
}

async function addComment(postId) {
    const commentInput = document.getElementById(`comment-${postId}`);
    const content = commentInput.value;
    if (!content.trim()) return;

    try {
        const response = await fetch(`${API_BASE}/posts/${postId}/comments`, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ content })
        });
        
        if (response.ok) {
            commentInput.value = '';
            loadFeed();
        }
    } catch (err) {
        alert('Error adding comment');
    }
}

function loadProfile() {
    if (!currentUser) return;
    
    document.getElementById('profileAvatar').textContent = currentUser.avatar;
    document.getElementById('profileName').textContent = currentUser.name;
    document.getElementById('profileUsername').textContent = `@${currentUser.username}`;
    document.getElementById('profileBio').textContent = currentUser.bio || 'No bio yet';
    
    // Load user's posts count
    fetch(`${API_BASE}/posts`, {
        headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(response => response.json())
    .then(posts => {
        const userPosts = posts.filter(post => post.userId === currentUser.id);
        document.getElementById('postCount').textContent = userPosts.length;
    });
    
    // Set edit form values
    document.getElementById('editName').value = currentUser.name;
    document.getElementById('editBio').value = currentUser.bio || '';
    document.getElementById('editAvatar').value = currentUser.avatar;
}

async function updateProfile() {
    const name = document.getElementById('editName').value;
    const bio = document.getElementById('editBio').value;
    const avatar = document.getElementById('editAvatar').value;

    try {
        const response = await fetch(`${API_BASE}/profile`, {
            method: 'PUT',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ name, bio, avatar })
        });
        
        if (response.ok) {
            const updatedUser = await response.json();
            currentUser = updatedUser;
            localStorage.setItem('user', JSON.stringify(updatedUser));
            loadProfile();
            alert('Profile updated successfully!');
        }
    } catch (err) {
        alert('Error updating profile');
    }
}

async function loadUsers() {
    // In a real app, you'd fetch users from the backend
    // For demo, we'll show some sample users
    const sampleUsers = [
        { id: 1, name: 'John Doe', username: 'john_doe', avatar: '👨', bio: 'Hello! I love social media!' },
        { id: 2, name: 'Jane Smith', username: 'jane_smith', avatar: '👩', bio: 'Tech enthusiast and blogger' },
        { id: 3, name: 'Mike Johnson', username: 'mike_j', avatar: '😊', bio: 'Travel lover and photographer' }
    ];
    
    const container = document.getElementById('usersContainer');
    container.innerHTML = sampleUsers.map(user => `
        <div class="user-card">
            <div class="user-info">
                <div class="user-avatar">${user.avatar}</div>
                <div>
                    <h3>${user.name}</h3>
                    <p>@${user.username}</p>
                    <p>${user.bio}</p>
                </div>
            </div>
            <button class="follow-btn" onclick="followUser(${user.id})" id="follow-${user.id}">
                Follow
            </button>
        </div>
    `).join('');
}

async function followUser(userId) {
    try {
        const response = await fetch(`${API_BASE}/users/${userId}/follow`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (response.ok) {
            const data = await response.json();
            const btn = document.getElementById(`follow-${userId}`);
            if (data.isFollowing) {
                btn.textContent = 'Following';
                btn.classList.add('following');
            } else {
                btn.textContent = 'Follow';
                btn.classList.remove('following');
            }
        }
    } catch (err) {
        alert('Error following user');
    }
}
async function loadUsers() {
    try {
        const response = await fetch(`${API_BASE}/users`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (response.ok) {
            const users = await response.json();
            const container = document.getElementById('usersContainer');
            container.innerHTML = users.map(user => `
                <div class="user-card">
                    <div class="user-info">
                        <div class="user-avatar">${user.avatar}</div>
                        <div>
                            <h3>${user.name}</h3>
                            <p>@${user.username}</p>
                            <p>${user.bio || 'No bio yet'}</p>
                            <div class="user-stats">
                                <small>Followers: ${user.followersCount} | Following: ${user.followingCount}</small>
                            </div>
                        </div>
                    </div>
                    <button class="follow-btn ${user.isFollowing ? 'following' : ''}" 
                            onclick="followUser(${user.id})" 
                            id="follow-${user.id}">
                        ${user.isFollowing ? 'Following' : 'Follow'}
                    </button>
                </div>
            `).join('');
        }
    } catch (err) {
        alert('Error loading users');
    }
}