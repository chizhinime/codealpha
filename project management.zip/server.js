const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const http = require('http');
const db = require('./database');
const WebSocketServer = require('./websocket');
require('dotenv').config();

const app = express();
const server = http.createServer(app);

// CORS configuration - allow multiple development origins
const allowedOrigins = [
    'http://localhost:8000',
    'http://127.0.0.1:5500',
    'http://localhost:5500',
    'http://127.0.0.1:8000',
    'http://localhost:3000',
    'http://127.0.0.1:3000'
];

app.use(cors({
    origin: function (origin, callback) {
        // Allow requests with no origin (like mobile apps or curl requests)
        if (!origin) return callback(null, true);
        
        if (allowedOrigins.indexOf(origin) === -1) {
            console.log('CORS blocked for origin:', origin);
            const msg = 'The CORS policy for this site does not allow access from the specified Origin.';
            return callback(new Error(msg), false);
        }
        console.log('CORS allowed for origin:', origin);
        return callback(null, true);
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Handle preflight requests
app.options('*', cors());

app.use(express.json());

const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'project-management-secret';

// Initialize WebSocket server
const wss = new WebSocketServer(server);

// Auth middleware
const authenticate = async (req, res, next) => {
    const token = req.header('Authorization');
    if (!token) return res.status(401).json({ error: 'No token' });

    try {
        const decoded = jwt.verify(token.replace('Bearer ', ''), JWT_SECRET);
        const result = await db.query('SELECT id, email FROM users WHERE id = $1', [decoded.id]);
        if (result.rows.length === 0) {
            return res.status(401).json({ error: 'User not found' });
        }
        req.user = decoded;
        next();
    } catch (err) {
        res.status(401).json({ error: 'Invalid token' });
    }
};

// Helper function to log activity
const logActivity = async (projectId, userId, action, description) => {
    await db.query(
        'INSERT INTO activities (project_id, user_id, action, description) VALUES ($1, $2, $3, $4)',
        [projectId, userId, action, description]
    );
};

// Helper function to create notification
const createNotification = async (userId, type, title, message, relatedId = null) => {
    await db.query(
        'INSERT INTO notifications (user_id, type, title, message, related_id) VALUES ($1, $2, $3, $4, $5)',
        [userId, type, title, message, relatedId]
    );
    
    // Send real-time notification via WebSocket
    if (wss && typeof wss.sendToUser === 'function') {
        wss.sendToUser(userId, {
            type: 'notification',
            notification: { type, title, message, relatedId }
        });
    }
};

// Auth Routes
app.post('/register', async (req, res) => {
    const { username, email, password, name } = req.body;
    
    try {
        const userCheck = await db.query(
            'SELECT id FROM users WHERE email = $1 OR username = $2',
            [email, username]
        );

        if (userCheck.rows.length > 0) {
            return res.status(400).json({ error: 'Email or username already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const result = await db.query(
            'INSERT INTO users (username, email, password, name) VALUES ($1, $2, $3, $4) RETURNING id, username, email, name, avatar',
            [username, email, hashedPassword, name]
        );

        const user = result.rows[0];
        const token = jwt.sign({ id: user.id, email }, JWT_SECRET);
        
        res.json({ token, user });
    } catch (err) {
        console.error('Registration error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const result = await db.query('SELECT * FROM users WHERE email = $1', [email]);
        const user = result.rows[0];

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign({ id: user.id, email }, JWT_SECRET);
        const { password: _, ...userWithoutPassword } = user;
        
        res.json({ token, user: userWithoutPassword });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Projects Routes
app.get('/projects', authenticate, async (req, res) => {
    try {
        const result = await db.query(
            `SELECT p.*, u.name as created_by_name,
                    COUNT(DISTINCT pm.user_id) as member_count,
                    COUNT(DISTINCT t.id) as task_count
             FROM projects p
             JOIN users u ON p.created_by = u.id
             LEFT JOIN project_members pm ON p.id = pm.project_id
             LEFT JOIN boards b ON p.id = b.project_id
             LEFT JOIN tasks t ON b.id = t.board_id
             WHERE p.id IN (SELECT project_id FROM project_members WHERE user_id = $1)
             GROUP BY p.id, u.id
             ORDER BY p.updated_at DESC`,
            [req.user.id]
        );

        res.json(result.rows);
    } catch (err) {
        console.error('Get projects error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/projects', authenticate, async (req, res) => {
    const { name, description, color } = req.body;
    
    try {
        const result = await db.query(
            `INSERT INTO projects (name, description, color, created_by) 
             VALUES ($1, $2, $3, $4) RETURNING *`,
            [name, description, color, req.user.id]
        );

        const project = result.rows[0];
        
        // Add creator as project owner
        await db.query(
            'INSERT INTO project_members (project_id, user_id, role) VALUES ($1, $2, $3)',
            [project.id, req.user.id, 'owner']
        );

        // Create default boards
        const defaultBoards = [
            { name: 'Backlog', color: '#6c757d', position: 0 },
            { name: 'To Do', color: '#007bff', position: 1 },
            { name: 'In Progress', color: '#ffc107', position: 2 },
            { name: 'Review', color: '#fd7e14', position: 3 },
            { name: 'Done', color: '#28a745', position: 4 }
        ];

        for (const board of defaultBoards) {
            await db.query(
                'INSERT INTO boards (project_id, name, color, position) VALUES ($1, $2, $3, $4)',
                [project.id, board.name, board.color, board.position]
            );
        }

        // Log activity
        await logActivity(project.id, req.user.id, 'project_created', `Created project "${name}"`);

        res.json(project);
    } catch (err) {
        console.error('Create project error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Boards Routes
app.get('/projects/:projectId/boards', authenticate, async (req, res) => {
    try {
        const result = await db.query(
            `SELECT b.*, 
                    COUNT(t.id) as task_count
             FROM boards b
             LEFT JOIN tasks t ON b.id = t.board_id
             WHERE b.project_id = $1
             GROUP BY b.id
             ORDER BY b.position`,
            [req.params.projectId]
        );

        res.json(result.rows);
    } catch (err) {
        console.error('Get boards error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Tasks Routes
app.get('/boards/:boardId/tasks', authenticate, async (req, res) => {
    try {
        const result = await db.query(
            `SELECT t.*, 
                    u.name as assigned_to_name,
                    u.avatar as assigned_to_avatar,
                    creator.name as created_by_name,
                    COUNT(DISTINCT tc.id) as comment_count
             FROM tasks t
             LEFT JOIN users u ON t.assigned_to = u.id
             LEFT JOIN users creator ON t.created_by = creator.id
             LEFT JOIN task_comments tc ON t.id = tc.task_id
             WHERE t.board_id = $1
             GROUP BY t.id, u.id, creator.id
             ORDER BY t.position`,
            [req.params.boardId]
        );

        res.json(result.rows);
    } catch (err) {
        console.error('Get tasks error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/boards/:boardId/tasks', authenticate, async (req, res) => {
    const { title, description, priority, due_date, assigned_to } = req.body;
    
    try {
        // Get current max position
        const positionResult = await db.query(
            'SELECT COALESCE(MAX(position), 0) as max_position FROM tasks WHERE board_id = $1',
            [req.params.boardId]
        );

        const result = await db.query(
            `INSERT INTO tasks (board_id, title, description, position, priority, due_date, assigned_to, created_by) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
            [req.params.boardId, title, description, positionResult.rows[0].max_position + 1, priority, due_date, assigned_to, req.user.id]
        );

        const task = result.rows[0];
        
        // Get board and project info for activity log
        const boardResult = await db.query(
            'SELECT b.*, p.name as project_name, p.id as project_id FROM boards b JOIN projects p ON b.project_id = p.id WHERE b.id = $1',
            [req.params.boardId]
        );

        const board = boardResult.rows[0];
        
        // Log activity
        await logActivity(board.project_id, req.user.id, 'task_created', `Created task "${title}" in ${board.name}`);

        // Send notification if assigned to someone
        if (assigned_to && assigned_to !== req.user.id) {
            await createNotification(
                assigned_to,
                'task_assigned',
                'New Task Assigned',
                `You have been assigned to "${title}"`,
                task.id
            );
        }

        // Broadcast task creation - FIXED: Check if wss exists and has the method
        if (wss && typeof wss.broadcastToProject === 'function') {
            wss.broadcastToProject(board.project_id, {
                type: 'task_created',
                task,
                boardId: parseInt(req.params.boardId)
            });
        }

        res.json(task);
    } catch (err) {
        console.error('Create task error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/tasks/:taskId', authenticate, async (req, res) => {
    const { title, description, priority, due_date, assigned_to, board_id, project_id } = req.body;
    
    try {
        const result = await db.query(
            `UPDATE tasks 
             SET title = $1, description = $2, priority = $3, due_date = $4, assigned_to = $5, board_id = $6, updated_at = CURRENT_TIMESTAMP 
             WHERE id = $7 RETURNING *`,
            [title, description, priority, due_date, assigned_to, board_id, req.params.taskId]
        );

        const task = result.rows[0];
        
        // Broadcast task update - FIXED: Check if wss exists and has the method
        if (wss && typeof wss.broadcastToProject === 'function' && project_id) {
            wss.broadcastToProject(project_id, {
                type: 'task_updated',
                task
            });
        }

        res.json(task);
    } catch (err) {
        console.error('Update task error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Comments Routes
app.get('/tasks/:taskId/comments', authenticate, async (req, res) => {
    try {
        const result = await db.query(
            `SELECT tc.*, u.name as user_name, u.avatar as user_avatar
             FROM task_comments tc
             JOIN users u ON tc.user_id = u.id
             WHERE tc.task_id = $1
             ORDER BY tc.created_at ASC`,
            [req.params.taskId]
        );

        res.json(result.rows);
    } catch (err) {
        console.error('Get comments error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/tasks/:taskId/comments', authenticate, async (req, res) => {
    const { content } = req.body;
    
    try {
        const result = await db.query(
            `INSERT INTO task_comments (task_id, user_id, content) 
             VALUES ($1, $2, $3) RETURNING *`,
            [req.params.taskId, req.user.id, content]
        );

        const comment = result.rows[0];
        
        // Get user details and task info
        const userResult = await db.query(
            'SELECT name, avatar FROM users WHERE id = $1',
            [req.user.id]
        );

        const taskResult = await db.query(
            'SELECT t.*, b.project_id FROM tasks t JOIN boards b ON t.board_id = b.id WHERE t.id = $1',
            [req.params.taskId]
        );

        const task = taskResult.rows[0];
        comment.user_name = userResult.rows[0].name;
        comment.user_avatar = userResult.rows[0].avatar;

        // Notify task assignee if different from commenter
        if (task.assigned_to && task.assigned_to !== req.user.id) {
            await createNotification(
                task.assigned_to,
                'comment_added',
                'New Comment',
                `${userResult.rows[0].name} commented on "${task.title}"`,
                task.id
            );
        }

        // Broadcast new comment - FIXED: Check if wss exists and has the method
        if (wss && typeof wss.broadcastToProject === 'function') {
            wss.broadcastToProject(task.project_id, {
                type: 'comment_added',
                comment,
                taskId: parseInt(req.params.taskId)
            });
        }

        res.json(comment);
    } catch (err) {
        console.error('Add comment error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Notifications Routes
app.get('/notifications', authenticate, async (req, res) => {
    try {
        const result = await db.query(
            `SELECT * FROM notifications 
             WHERE user_id = $1 
             ORDER BY created_at DESC 
             LIMIT 50`,
            [req.user.id]
        );

        res.json(result.rows);
    } catch (err) {
        console.error('Get notifications error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/notifications/:id/read', authenticate, async (req, res) => {
    try {
        await db.query(
            'UPDATE notifications SET is_read = true WHERE id = $1 AND user_id = $2',
            [req.params.id, req.user.id]
        );

        res.json({ success: true });
    } catch (err) {
        console.error('Mark notification read error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Users Routes
app.get('/users', authenticate, async (req, res) => {
    try {
        const result = await db.query(
            'SELECT id, name, email, avatar FROM users ORDER BY name'
        );

        res.json(result.rows);
    } catch (err) {
        console.error('Get users error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

server.listen(PORT, () => {
    console.log(`Project Management API running on http://localhost:${PORT}`);
    console.log('CORS enabled for origins:', allowedOrigins);
});