const WebSocket = require('ws');
const jwt = require('jsonwebtoken');
require('dotenv').config();

// Use environment variable for JWT secret
const JWT_SECRET = process.env.JWT_SECRET || 'project-management-secret';

class WebSocketServer {
    constructor(server) {
        if (!server) {
            throw new Error('WebSocketServer requires an HTTP server instance');
        }
        
        this.wss = new WebSocket.Server({ 
            server,
            verifyClient: (info, done) => {
                // Verify token during connection attempt
                const url = new URL(info.req.url, `http://${info.req.headers.host}`);
                const token = url.searchParams.get('token');
                
                if (!token) {
                    console.log('WebSocket connection rejected: No token provided');
                    return done(false, 401, 'Unauthorized');
                }
                
                try {
                    jwt.verify(token, JWT_SECRET);
                    done(true);
                } catch (error) {
                    console.log('WebSocket connection rejected: Invalid token');
                    done(false, 401, 'Unauthorized');
                }
            }
        });
        
        this.clients = new Map();
        
        this.wss.on('connection', (ws, req) => {
            const url = new URL(req.url, `http://${req.headers.host}`);
            const token = url.searchParams.get('token');
            
            try {
                const decoded = jwt.verify(token, JWT_SECRET);
                const userId = decoded.id;
                
                this.clients.set(userId, ws);
                console.log(`User ${userId} connected via WebSocket`);
                
                ws.on('close', () => {
                    this.clients.delete(userId);
                    console.log(`User ${userId} disconnected`);
                });
                
                ws.on('error', (error) => {
                    console.error('WebSocket error:', error);
                    this.clients.delete(userId);
                });
                
                // Send welcome message
                ws.send(JSON.stringify({
                    type: 'connection',
                    message: 'WebSocket connected successfully'
                }));
                
            } catch (error) {
                console.error('WebSocket authentication failed:', error);
                ws.close(1008, 'Authentication failed');
            }
        });

        console.log('WebSocket server initialized successfully');
    }
    
    // Broadcast to all clients in a project
    broadcastToProject(projectId, message) {
        if (!this.clients || this.clients.size === 0) {
            return; // No connected clients
        }
        
        const data = JSON.stringify({
            ...message,
            timestamp: new Date().toISOString()
        });
        
        this.clients.forEach((ws, userId) => {
            if (ws && ws.readyState === WebSocket.OPEN) {
                try {
                    ws.send(data);
                } catch (error) {
                    console.error('Error sending WebSocket message:', error);
                }
            }
        });
    }
    
    // Send to specific user
    sendToUser(userId, message) {
        const ws = this.clients.get(userId);
        if (ws && ws.readyState === WebSocket.OPEN) {
            try {
                ws.send(JSON.stringify({
                    ...message,
                    timestamp: new Date().toISOString()
                }));
            } catch (error) {
                console.error('Error sending WebSocket message to user:', error);
            }
        }
    }

    // Get connected clients count (for debugging)
    getConnectedClients() {
        return this.clients.size;
    }
}

module.exports = WebSocketServer;