const API_BASE = 'http://localhost:3001';
let currentUser = null;
let token = localStorage.getItem('token');
let currentProject = null;
let websocket = null;
let unreadNotifications = 0;

// Helper function to make authenticated API calls
async function apiCall(url, options = {}) {
    const config = {
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            ...options.headers
        },
        ...options
    };
    
    const response = await fetch(`${API_BASE}${url}`, config);
    
    if (response.status === 401) {
        // Token expired or invalid
        logout();
        throw new Error('Authentication failed');
    }
    
    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Request failed');
    }
    
    return response.json();
}

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    if (token) {
        checkAuth();
    } else {
        showAuth();
    }
    
    // Navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tab = this.getAttribute('data-tab');
            showTab(tab);
        });
    });
    
    // Logout
    document.getElementById('logoutBtn').addEventListener('click', logout);
});

async function checkAuth() {
    try {
        const userData = localStorage.getItem('user');
        if (userData) {
            currentUser = JSON.parse(userData);
            hideAuth();
            loadProjects();
            connectWebSocket();
            loadNotifications();
        } else {
            showAuth();
        }
    } catch (err) {
        showAuth();
    }
}

async function register() {
    const name = document.getElementById('registerName').value;
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    if (!name || !username || !email || !password) {
        alert('Please fill all fields');
        return;
    }

    try {
        const data = await apiCall('/register', {
            method: 'POST',
            body: JSON.stringify({ name, username, email, password })
        });
        handleAuthSuccess(data);
    } catch (err) {
        alert('Error: ' + err.message);
    }
}

async function login() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    if (!email || !password) {
        alert('Please fill all fields');
        return;
    }

    try {
        const data = await apiCall('/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        handleAuthSuccess(data);
    } catch (err) {
        alert('Error: ' + err.message);
    }
}

function handleAuthSuccess(data) {
    token = data.token;
    currentUser = data.user;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(currentUser));
    hideAuth();
    loadProjects();
    connectWebSocket();
    loadNotifications();
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    token = null;
    currentUser = null;
    if (websocket) {
        websocket.close();
    }
    showAuth();
}

function showAuth() {
    document.getElementById('authSection').classList.remove('hidden');
    document.getElementById('appContent').classList.add('hidden');
}

function hideAuth() {
    document.getElementById('authSection').classList.add('hidden');
    document.getElementById('appContent').classList.remove('hidden');
}

function showTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    document.getElementById(tabName + 'Tab').classList.add('active');
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    if (tabName === 'projects') loadProjects();
    if (tabName === 'notifications') loadNotifications();
}

// WebSocket connection
function connectWebSocket() {
    if (!token) return;
    
    try {
        websocket = new WebSocket(`ws://localhost:3001?token=${token}`);
        
        websocket.onopen = function() {
            console.log('WebSocket connected');
        };
        
        websocket.onmessage = function(event) {
            const data = JSON.parse(event.data);
            handleWebSocketMessage(data);
        };
        
        websocket.onclose = function() {
            console.log('WebSocket disconnected');
            // Attempt to reconnect after 5 seconds
            setTimeout(connectWebSocket, 5000);
        };
        
        websocket.onerror = function(error) {
            console.error('WebSocket error:', error);
        };
        
    } catch (error) {
        console.error('WebSocket connection failed:', error);
    }
}

function handleWebSocketMessage(data) {
    switch (data.type) {
        case 'notification':
            showNotification(data.notification);
            loadNotifications(); // Refresh notifications list
            break;
            
        case 'task_created':
        case 'task_updated':
            if (currentProject && data.task) {
                loadProjectBoards(currentProject.id);
            }
            break;
            
        case 'comment_added':
            if (document.getElementById('taskDetailModal').classList.contains('hidden') === false) {
                loadTaskComments(currentTaskId);
            }
            break;
    }
}

function showNotification(notification) {
    // Show toast notification
    const toast = document.createElement('div');
    toast.className = 'notification-toast';
    toast.innerHTML = `
        <strong>${notification.title}</strong>
        <p>${notification.message}</p>
    `;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        padding: 1rem;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        border-left: 4px solid #3498db;
        z-index: 1001;
        max-width: 300px;
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

// Projects
async function loadProjects() {
    try {
        const projects = await apiCall('/projects');
        
        const grid = document.getElementById('projectsGrid');
        grid.innerHTML = projects.map(project => `
            <div class="project-card" onclick="openProject(${project.id})" style="border-left-color: ${project.color}">
                <h3>${project.name}</h3>
                <p>${project.description || 'No description'}</p>
                <div class="project-stats">
                    <span>👥 ${project.member_count} members</span>
                    <span>📋 ${project.task_count} tasks</span>
                </div>
            </div>
        `).join('');
    } catch (err) {
        alert('Error loading projects: ' + err.message);
    }
}

function showCreateProjectModal() {
    document.getElementById('createProjectModal').classList.remove('hidden');
}

async function createProject() {
    const name = document.getElementById('projectName').value;
    const description = document.getElementById('projectDescription').value;
    const color = document.getElementById('projectColor').value;

    if (!name) {
        alert('Project name is required');
        return;
    }

    try {
        await apiCall('/projects', {
            method: 'POST',
            body: JSON.stringify({ name, description, color })
        });
        
        hideModal('createProjectModal');
        loadProjects();
    } catch (err) {
        alert('Error creating project: ' + err.message);
    }
}

async function openProject(projectId) {
    try {
        const projects = await apiCall('/projects');
        
        currentProject = projects.find(p => p.id === projectId);
        if (!currentProject) return;
        
        document.getElementById('projectTitle').textContent = currentProject.name;
        document.getElementById('projectDescription').textContent = currentProject.description || 'No description';
        
        showTab('projectBoard');
        loadProjectBoards(projectId);
        loadUsers(); // Load users for task assignment
    } catch (err) {
        alert('Error opening project: ' + err.message);
    }
}

function showProjects() {
    showTab('projects');
}

// Boards and Tasks
async function loadProjectBoards(projectId) {
    try {
        const boards = await apiCall(`/projects/${projectId}/boards`);
        
        const container = document.getElementById('boardsContainer');
        container.innerHTML = '';
        
        for (const board of boards) {
            const boardElement = document.createElement('div');
            boardElement.className = 'board';
            boardElement.innerHTML = `
                <div class="board-header">
                    <h3>${board.name}</h3>
                    <span class="board-task-count">${board.task_count}</span>
                </div>
                <div class="tasks-list" id="tasks-${board.id}"></div>
            `;
            container.appendChild(boardElement);
            
            await loadBoardTasks(board.id);
        }
    } catch (err) {
        alert('Error loading boards: ' + err.message);
    }
}

async function loadBoardTasks(boardId) {
    try {
        const tasks = await apiCall(`/boards/${boardId}/tasks`);
        
        const container = document.getElementById(`tasks-${boardId}`);
        container.innerHTML = tasks.map(task => `
            <div class="task-card" onclick="openTaskDetail(${task.id})" style="border-left-color: ${getPriorityColor(task.priority)}">
                <h4>${task.title}</h4>
                <p>${task.description || 'No description'}</p>
                <div class="task-meta">
                    <span class="priority-tag priority-${task.priority}">${task.priority}</span>
                    ${task.assigned_to_name ? `
                        <div class="assigned-to">
                            <span>${task.assigned_to_avatar}</span>
                            <span>${task.assigned_to_name}</span>
                        </div>
                    ` : '<span>Unassigned</span>'}
                </div>
            </div>
        `).join('');
    } catch (err) {
        console.error('Error loading tasks:', err);
    }
}

function getPriorityColor(priority) {
    const colors = {
        low: '#28a745',
        medium: '#ffc107',
        high: '#fd7e14',
        urgent: '#dc3545'
    };
    return colors[priority] || '#6c757d';
}

function showCreateTaskModal() {
    document.getElementById('createTaskModal').classList.remove('hidden');
}

async function createTask() {
    const title = document.getElementById('taskTitle').value;
    const description = document.getElementById('taskDescription').value;
    const priority = document.getElementById('taskPriority').value;
    const assigned_to = document.getElementById('taskAssignee').value || null;
    const due_date = document.getElementById('taskDueDate').value || null;

    if (!title) {
        alert('Task title is required');
        return;
    }

    // Get first board (To Do) for new tasks
    const boards = await apiCall(`/projects/${currentProject.id}/boards`);
    const todoBoard = boards.find(b => b.name === 'To Do') || boards[0];

    try {
        await apiCall(`/boards/${todoBoard.id}/tasks`, {
            method: 'POST',
            body: JSON.stringify({ 
                title, 
                description, 
                priority, 
                assigned_to: assigned_to ? parseInt(assigned_to) : null,
                due_date 
            })
        });
        
        hideModal('createTaskModal');
        loadProjectBoards(currentProject.id);
    } catch (err) {
        alert('Error creating task: ' + err.message);
    }
}

// Task Details
let currentTaskId = null;

async function openTaskDetail(taskId) {
    currentTaskId = taskId;
    
    try {
        // Get task details from boards
        const boards = await apiCall(`/projects/${currentProject.id}/boards`);
        
        let task = null;
        for (const board of boards) {
            const tasks = await apiCall(`/boards/${board.id}/tasks`);
            task = tasks.find(t => t.id === taskId);
            if (task) break;
        }
        
        if (!task) {
            alert('Task not found');
            return;
        }
        
        document.getElementById('taskDetailTitle').textContent = task.title;
        document.getElementById('taskDetailDescription').textContent = task.description || 'No description';
        document.getElementById('taskDetailAssignee').textContent = task.assigned_to_name || 'Unassigned';
        document.getElementById('taskDetailPriority').textContent = task.priority;
        document.getElementById('taskDetailPriority').className = `priority-tag priority-${task.priority}`;
        document.getElementById('taskDetailDueDate').textContent = task.due_date ? new Date(task.due_date).toLocaleDateString() : 'No due date';
        
        loadTaskComments(taskId);
        document.getElementById('taskDetailModal').classList.remove('hidden');
    } catch (err) {
        alert('Error loading task details: ' + err.message);
    }
}

async function loadTaskComments(taskId) {
    try {
        const comments = await apiCall(`/tasks/${taskId}/comments`);
        
        const container = document.getElementById('taskComments');
        container.innerHTML = comments.map(comment => `
            <div class="comment">
                <div class="comment-header">
                    <div class="comment-user">
                        <span>${comment.user_avatar}</span>
                        <span>${comment.user_name}</span>
                    </div>
                    <div class="comment-time">${new Date(comment.created_at).toLocaleString()}</div>
                </div>
                <div class="comment-content">${comment.content}</div>
            </div>
        `).join('');
    } catch (err) {
        console.error('Error loading comments:', err);
    }
}

async function addComment() {
    const content = document.getElementById('newComment').value;
    if (!content.trim()) return;

    try {
        await apiCall(`/tasks/${currentTaskId}/comments`, {
            method: 'POST',
            body: JSON.stringify({ content })
        });
        
        document.getElementById('newComment').value = '';
        loadTaskComments(currentTaskId);
    } catch (err) {
        alert('Error adding comment: ' + err.message);
    }
}

// Users
async function loadUsers() {
    try {
        const users = await apiCall('/users');
        
        const select = document.getElementById('taskAssignee');
        select.innerHTML = '<option value="">Unassigned</option>' +
            users.map(user => `<option value="${user.id}">${user.name} (${user.email})</option>`).join('');
    } catch (err) {
        console.error('Error loading users:', err);
    }
}

// Notifications
async function loadNotifications() {
    try {
        const notifications = await apiCall('/notifications');
        
        unreadNotifications = notifications.filter(n => !n.is_read).length;
        updateNotificationBadge();
        
        const container = document.getElementById('notificationsList');
        container.innerHTML = notifications.map(notification => `
            <div class="notification-item ${notification.is_read ? '' : 'unread'}">
                <div class="notification-header">
                    <div class="notification-title">${notification.title}</div>
                    <div class="notification-time">${new Date(notification.created_at).toLocaleString()}</div>
                </div>
                <div class="notification-message">${notification.message}</div>
                ${!notification.is_read ? `
                    <button onclick="markNotificationRead(${notification.id})" style="margin-top: 0.5rem; padding: 0.25rem 0.5rem; background: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 0.8rem;">
                        Mark as Read
                    </button>
                ` : ''}
            </div>
        `).join('');
    } catch (err) {
        alert('Error loading notifications: ' + err.message);
    }
}

function updateNotificationBadge() {
    const badge = document.getElementById('notificationCount');
    if (unreadNotifications > 0) {
        badge.textContent = unreadNotifications;
        badge.classList.remove('hidden');
    } else {
        badge.classList.add('hidden');
    }
}

async function markNotificationRead(notificationId) {
    try {
        await apiCall(`/notifications/${notificationId}/read`, {
            method: 'PUT'
        });
        loadNotifications();
    } catch (err) {
        alert('Error marking notification as read: ' + err.message);
    }
}

async function markAllNotificationsRead() {
    try {
        const notifications = await apiCall('/notifications');
        
        const unreadNotifications = notifications.filter(n => !n.is_read);
        for (const notification of unreadNotifications) {
            await apiCall(`/notifications/${notification.id}/read`, {
                method: 'PUT'
            });
        }
        
        loadNotifications();
    } catch (err) {
        alert('Error marking all notifications as read: ' + err.message);
    }
}

// Utility functions
function hideModal(modalId) {
    document.getElementById(modalId).classList.add('hidden');
}

// Close modals when clicking outside
document.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.add('hidden');
    }
});